# dbgprint

Debug Print is a handy command line print app used for debugging loops and variable changes over time.

It has features for tracking pivots in a while and for loop, and also print the information and data types of variables

Its dependencies are termcolor and colorama.

For python package: https://pypi.org/project/dbgprint/1.0.0/

For github repo: https://github.com/youhengzhou/dbgprint
